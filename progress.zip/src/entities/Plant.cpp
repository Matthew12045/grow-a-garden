#include "Plant.h"
#include "mutation.h"
#include "../world/Cell.h"
#include <utility>
#include <algorithm>

Plant::Plant(int id,
    const std::string name,
    int currentStage,
    int maxStages,
    std::size_t ticksPerStage,
    std::size_t ticksElapsed,
    double sellPrice,
    bool regrowsAfterHarvest,
    int regrowStage)
    : id_(id),
    name_(std::move(name)),
    currentStage_(currentStage),
    maxStages_(maxStages),
    ticksPerStage_(ticksPerStage),
    ticksElapsed_(ticksElapsed),
    sellPrice_(sellPrice),
    mutations_(),
    regrowsAfterHarvest_(regrowsAfterHarvest),
    consumedOnHarvest_(true),
    regrowStage_(regrowStage) {}

void Plant::grow(std::size_t ticks)
{
    if (ticks == 0 || ticksPerStage_ == 0 || maxStages_ <= 0) {
        return;
    }

    const std::size_t maxTicks = static_cast<std::size_t>(maxStages_) * ticksPerStage_;
    if (ticksElapsed_ >= maxTicks) {
        ticksElapsed_ = maxTicks;
        currentStage_ = maxStages_;
        return;
    }

    const std::size_t remainingTicks = maxTicks - ticksElapsed_;
    const std::size_t ticksToApply = (ticks < remainingTicks) ? ticks : remainingTicks;
    ticksElapsed_ += ticksToApply;

    currentStage_ = static_cast<int>(ticksElapsed_ / ticksPerStage_);
    if (currentStage_ > maxStages_) {
        currentStage_ = maxStages_;
    }
}

HarvestedItem Plant::harvest()
{
    if (!isFullyGrown()) return HarvestedItem{};

    // copy mutations from plant to harvested item
    std::vector<MutationType> harvestedMutations;
    for (const auto& m : mutations_) {
        harvestedMutations.push_back(m.getType());
    }

    HarvestedItem item(calcPrice(), harvestedMutations);

    if (regrowsAfterHarvest_) {
        currentStage_ = regrowStage_;
        ticksElapsed_ = regrowStage_ * ticksPerStage_;
        mutations_.clear();
        consumedOnHarvest_ = false;
    } else {
        consumedOnHarvest_ = true;
    }

    return item;
}

bool Plant::isFullyGrown() const
{
    return (currentStage_ == maxStages_) ? true : false;
}

std::size_t Plant::getTimeToGrowth() const
{
    if (ticksPerStage_ == 0 || maxStages_ <= 0) {
        return 0;
    }

    const std::size_t maxTicks =
        static_cast<std::size_t>(maxStages_) * ticksPerStage_;

    if (ticksElapsed_ >= maxTicks || currentStage_ >= maxStages_) {
        return 0;
    }

    return maxTicks - ticksElapsed_;
}

void Plant::applyWeatherEffect(WeatherType weatherType)
{

}

void Plant::addMutation(Mutation newMutation)
{
    // for(const auto& m : mutations_)
    // {
    //     if (newMutation.getType() == m.getType()) return;
    // }
    // mutations_.push_back(newMutation);

    const auto it = std::find_if(mutations_.begin(), mutations_.end(),
            [&](const Mutation& m) {
                return m.getType() == newMutation.getType();
            });

    if (it != mutations_.end()) {
        return;
    }

    mutations_.push_back(newMutation);
}


std::vector<MutationType> Plant::getMutations() const
{
    // mutation type
    std::vector<MutationType> mt;
    mt.reserve(mutations_.size());
    for (const auto& m : mutations_)
    {
        mt.push_back(m.getType());
    }
    return mt;
}

double Plant::clacPrice()
{
    double finalPrice = sellPrice_;
    for (const auto& m : mutations_)
    {
        finalPrice *= m.getMultiplier();
    }
    return finalPrice;
}